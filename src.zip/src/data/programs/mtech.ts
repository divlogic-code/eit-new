// Content for this area lives here — never inside components.
// Intentionally empty until real content is supplied. Do not add placeholder statistics.

import type { ProgramDetail } from "./programs";

export const mtech: ProgramDetail | null = null;
