import type { ReactNode } from "react";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PageHero } from "@/components/pages/PageHero";
import { PageSection } from "@/components/pages/PageSection";
import { QuickLinksGrid, type QuickLink } from "@/components/pages/QuickLinksGrid";
import { SectionNote } from "@/components/pages/SectionNote";
import { ScrollAnimator } from "@/components/animations/ScrollAnimator";
import { getDepartment, departments } from "@/data/departments/departments";
import { departmentContent } from "@/data/departments/content";
import { getRouteMetadata } from "@/lib/metadata";

export const dynamicParams = false;
export function generateStaticParams() {return departments.flatMap(d=>d.sections.map(s=>({department:d.slug,section:s.slug})));}
export async function generateMetadata(props: PageProps<"/departments/[department]/[section]">): Promise<Metadata> {const {department,section}=await props.params;return getRouteMetadata(`/departments/${department}/${section}`);}
function Content({data,slug}:{data:(typeof departmentContent)[keyof typeof departmentContent];slug:string}){
 const d = data as unknown as Record<string, unknown>;
 const original = (d.original || {}) as Record<string, unknown>;
 const blocks:ReactNode[]=[];
 const add=(heading:string,body:unknown)=>{if(typeof body!=="string"||!body.trim())return;blocks.push(<div key={`${heading}-${blocks.length}`} data-anim="card" className="rounded-2xl border border-primary/10 bg-eit-surface p-7 sm:p-9"><h3 className="mb-3 text-xl font-semibold text-primary">{heading}</h3><p className="whitespace-pre-line leading-8 text-primary">{body}</p></div>)};
 const extract=(item:unknown):string=>{if(typeof item==="string")return item;if(!item||typeof item!=="object")return "";const o=item as Record<string,unknown>;return String(o.text||o.description||o.message||"")};
 const addItems=(label:string,items:unknown)=>{if(!Array.isArray(items))return;items.forEach((v,i)=>add(`${label} ${i+1}`,extract(v)))};
 if(slug==="overview") {add("Department Overview",d.overview);addItems("Department Highlight",d.overviewDetails)}
 if(slug==="hod-message") {const h=d.hod as Record<string,unknown>|undefined;add(typeof h?.name==="string"&&h.name?h.name:"Head of Department",h?.message)}
 if(slug==="vision"||slug==="vision-mission") {add("Vision",d.vision);addItems("Mission M",d.mission)}
 if(["peo","peo-po-pso","pos"].includes(slug)) {
  const approved=d.approvedPEO as unknown[]|undefined;
  if(approved?.length){addItems("PEO",approved);addItems("PSO",d.approvedPSO)}
  else {const outcomes=d.outcomes as Record<string,unknown>|undefined;
   for(const [key,label] of [["peo","PEO"],["po","PO"],["pso","PSO"]]){
    if(slug==="pos"&&key!=="po")continue;
    const section=outcomes?.[key] as Record<string,unknown>|undefined;
    addItems(label,section?.items);
   }
   if(!outcomes||!Object.keys(outcomes).length){addItems("PEO",original.peo);addItems("PSO",original.pso)}
  }
 }
 if(slug==="faculty") {const faculty=d.faculty; if(Array.isArray(faculty))faculty.forEach((person,i)=>{if(Array.isArray(person))add(String(person[0]||`Faculty ${i+1}`),person.slice(1).filter(Boolean).join(" · "));else if(person&&typeof person==="object"){const obj=person as Record<string,unknown>;add(String(obj.name||`Faculty ${i+1}`),Object.entries(obj).filter(([k])=>k!=="name").map(([,v])=>String(v)).filter(Boolean).join(" · "))}})}
 if(slug==="dqac")addItems("DQAC Member",d.dqacMembers);
 if(slug==="newsletter"&&Array.isArray(d.newsletters))d.newsletters.forEach((entry:unknown)=>{const n=entry as {href:string,title:string};blocks.push(<a key={n.href} href={n.href} target="_blank" rel="noopener noreferrer" className="block rounded-2xl border border-primary/10 bg-eit-surface p-8 text-lg font-semibold text-primary underline underline-offset-4">{n.title} (PDF)</a>)});
 if(slug==="labs"&&d.labsInactive)return <SectionNote title="Laboratories temporarily inactive">This section is currently in progress, as instructed by the department.</SectionNote>;
 if(slug==="labs") {const labs=original.laboratories||original.labs;if(Array.isArray(labs))addItems("Laboratory",labs);else if(typeof labs==="string")add("Department Laboratories",labs);}
 if(!blocks.length)return <SectionNote title="Department records pending">No verified content for this section was found in the supplied original source. Information has not been invented.</SectionNote>;
 return <div className="grid gap-5 md:grid-cols-2">{blocks}</div>;
}
export default async function Page(props:PageProps<"/departments/[department]/[section]">){
 const {department:slug,section:sectionSlug}=await props.params;const dept=getDepartment(slug);const section=dept?.sections.find(s=>s.slug===sectionSlug);if(!dept||!section||!(slug in departmentContent))notFound();
 const data=departmentContent[slug as keyof typeof departmentContent];const path=`/departments/${slug}/${sectionSlug}`;
 const links:QuickLink[]=dept.sections.filter(s=>s.slug!==sectionSlug).map(s=>({href:`/departments/${slug}/${s.slug}`,label:s.title}));
 return <><PageHero path={path} eyebrow={dept.name} title={[section.title]} description={`${section.title} for the ${dept.shortName} department.`} secondaryAction={{label:`Back to ${dept.shortName}`,href:`/departments/${slug}`}}/>
 <PageSection name="default" eyebrow={dept.shortName} title={[section.title]}><Content data={data} slug={sectionSlug}/>{links.length>0&&<div className="mt-12"><QuickLinksGrid links={links} columns={3}/></div>}</PageSection><ScrollAnimator/></>;
}
